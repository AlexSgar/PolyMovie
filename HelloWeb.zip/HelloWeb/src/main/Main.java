package main;

import java.sql.SQLException;


public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] arg) throws SQLException{
		
		
		//HelloController j= new HelloController();
		//j.retrieveActorID();
	}

}
