package it.uniroma.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class MainController {
	private  Set<String> actorsRetrieved;
	private  Set<String> movieRetrived;
	private  Set<String> tvShowRetrived;
	final  String username="postgres";
	final  String password="";
	private String dbUrl="jdbc:postgresql://localhost/moviedb";


	public MainController() {
	}



	@RequestMapping(value="movie/{id}/actors",method = RequestMethod.GET)
	public String getActorsInMovies(@PathVariable("id") String id_movie ,Model model) throws SQLException {
		retrieveActors4Movie(id_movie);
		int size = this.actorsRetrieved.size();
		model.addAttribute("actors",new LinkedList<String>(this.actorsRetrieved));
		return  "actor-list";
	}


	@RequestMapping(value="actor/{id}/movies",method = RequestMethod.GET)
	public String getMoviesWithActor(@PathVariable("id") String id_actor ,Model model) throws SQLException {
		retrieveMovies4Actor(id_actor);
		int size = this.movieRetrived.size();
		model.addAttribute("movies",new LinkedList<String>(this.movieRetrived));
		return  "movie-list";
	}



	@RequestMapping(value="actor/{id}/tvshows",method = RequestMethod.GET)
	public String getTVShowWithActor(@PathVariable("id") String id_actor ,Model model) throws SQLException {
		retrieveTvShow4Actor(id_actor);
		int size = this.movieRetrived.size();
		model.addAttribute("tvShow",new LinkedList<String>(this.tvShowRetrived));
		return  "tvshow-list";
	}


	@RequestMapping(value="tv/{id}/actors",method = RequestMethod.GET)
	public String getActors4TVShow(@PathVariable("id") String id_serie ,Model model) throws SQLException {
		retrieveActors4TV(id_serie);
		int size = this.actorsRetrieved.size();
		model.addAttribute("actors",new LinkedList<String>(this.actorsRetrieved));
		return  "actor-list";
	}




	private void retrieveActors4TV(String id_serie) throws SQLException {
		this.actorsRetrieved=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = "select distinct a.id_actor  from actors a join tvroles"
				+ " tv on a.id_actor=tv.id_actor where tv.id_serie='"+id_serie+"'";
		stmt = conn.createStatement();
		ResultSet rs= stmt.executeQuery(query);
		while (rs.next()) {
			this.actorsRetrieved.add(rs.getString("id_actor"));}
		conn.close();

	}



	private void retrieveTvShow4Actor(String id_actor) throws SQLException {
		this.tvShowRetrived=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = "select distinct ts.id_serie,ts.name  from tvshow ts join "
				+ "tvroles tr on tr.id_serie=ts.id_serie where id_actor='"+id_actor+"'";
		stmt = conn.createStatement();
		ResultSet rs= stmt.executeQuery(query);
		while (rs.next()) {
			this.tvShowRetrived.add(rs.getString("name"));}
		conn.close();

	}



	private void retrieveActors4Movie(String id_movie) throws SQLException {
		this.actorsRetrieved=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = "select distinct id_actor  from credits c join moviecredits"
				+ " m on m.id_credit=c.id_credit where m.id_movie='"+id_movie+"'";
		stmt = conn.createStatement();
		ResultSet rs= stmt.executeQuery(query);
		while (rs.next()) {
			this.actorsRetrieved.add(rs.getString("id_actor"));}
		conn.close();

	}


	private void retrieveMovies4Actor(String id_actor) throws SQLException {
		this.movieRetrived=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = "select distinct id_movie from credits c join moviecredits"
				+ " m on m.id_credit=c.id_credit where c.id_actor='"+id_actor+"'";
		stmt = conn.createStatement();
		ResultSet rs= stmt.executeQuery(query);
		while (rs.next()) {
			this.movieRetrived.add(rs.getString("id_movie"));}
		conn.close();

	}





	@RequestMapping(value="movie",method = RequestMethod.GET)
	public String getMovies(Model model) throws SQLException {
		retrieveMovieID();
		int size = this.movieRetrived.size();
		model.addAttribute("message", "film trovati: "+size);
		LinkedList<String> linkedList = new LinkedList<String>(this.movieRetrived);
		model.addAttribute("movies",linkedList.subList(0,100));
		return  "movie-list";
	}



	@RequestMapping(value="actor",method = RequestMethod.GET)
	public String getActors(Model model) throws SQLException {
		retrieveActorID();
		int size = this.actorsRetrieved.size();
		model.addAttribute("actors",new LinkedList<String>(this.actorsRetrieved));
		return  "actor-list";
	}


	@RequestMapping(value="tv", method = RequestMethod.GET)
	public String getTVShows(@PathVariable("id") String id_attore ,Model model) throws SQLException {
		retrieveActorID();
		model.addAttribute("attore",this.retrieveActorID(id_attore));
		return  "tvshow-list";
	}



	@RequestMapping(value="actor/{id}", method = RequestMethod.GET)
	public String getSingleActor(@PathVariable("id") String id_attore ,Model model) throws SQLException {

		model.addAttribute("attore",this.retrieveActorID(id_attore));
		return  "tvshow-list";
	}


	@RequestMapping(value="movie/{id}/actor", method = RequestMethod.GET)
	public String getMovieActors(@PathVariable("id") String id_attore ,Model model) throws SQLException {

		model.addAttribute("attore",this.retrieveActorID(id_attore));
		return  "tvshow-list";
	}




	public Connection getConnection(String url) throws SQLException{
		Connection conn = DriverManager.getConnection(url,username,password);
		return conn;
	}






	public String retrieveActorID(String attore) throws SQLException {
		this.actorsRetrieved=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = " select * from actors where id_actor='"+attore+"'";
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		if (rs.next()) {
			return (rs.getString("name"));
		}
		conn.close();
		return " non trovato";

	}




	public void retrieveMovieID() throws SQLException {
		this.movieRetrived=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = " select distinct id_movie from moviecredits order by id_movie";
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next()) {
			this.movieRetrived.add(rs.getString("id_movie"));}
		conn.close();

		System.out.println(movieRetrived.size());



	}


	public void retrieveActorID() throws SQLException {
		this.actorsRetrieved=new HashSet<String>();
		Connection conn= this.getConnection(this.dbUrl);
		Statement stmt = null;
		String query = " select distinct id_actor from credits order by id_actor";
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		while (rs.next()) {
			this.actorsRetrieved.add(rs.getString("id_actor"));}
		conn.close();

		System.out.println(actorsRetrieved.size());
	}



}
